import type { Metadata } from "next";
import { Inter, Outfit } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import { cn } from "@/lib/utils";

import { CSPostHogProvider } from './providers';
import { AuthProvider } from '@/context/AuthContext';

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit" });

export const metadata: Metadata = {
    title: "AI Daily Intelligence",
    description: "Your daily brief of AI news, tailored to your persona.",
};

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="en" suppressHydrationWarning>
            <body
                className={cn(inter.variable, outfit.variable, "font-sans bg-background text-foreground min-h-screen")}
                suppressHydrationWarning
            >
                <CSPostHogProvider>
                    <AuthProvider>
                        {children}
                    </AuthProvider>
                </CSPostHogProvider>
            </body>
        </html>
    );
}
